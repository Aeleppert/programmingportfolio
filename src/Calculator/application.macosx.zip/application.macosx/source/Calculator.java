import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Calculator extends PApplet {

Button[] numButtons = new Button[11];
Button[] opButtons = new Button[13];
String disVal = "0.0";
String op = "";//operator to use in calc
boolean left = true;
float r = 0.0f;//what is right of operator
float l = 0.0f;//what is left of operator
float result = 0.0f;//the answer

public void setup() {
  //Is this the calculator size or the actual size?
  
  numButtons[0] = new Button(200, 140, 280, 140, 240, 200, "7", 0xffFCF000,0xffFCF670, true,false);
  numButtons[1] = new Button(260, 200, 300, 140, 340, 200, "8", 0xffFCF000,0xffFCF670, true,true);
  numButtons[2] = new Button(320, 140, 400, 140, 360, 200, "9", 0xffFCF000,0xffFCF670, true,false);
  numButtons[3] = new Button(200, 280, 240, 220, 280, 280, "4", 0xffFFF639,0xffFFFA9B, true,true);
  numButtons[4] = new Button(260, 220, 340, 220, 300, 280, "5", 0xffFFF639,0xffFFFA9B,true,false);
  numButtons[5] = new Button(320, 280, 360, 220, 400, 280, "6", 0xffFFF639,0xffFFFA9B,true,true);
  numButtons[6] = new Button(200, 300, 280, 300, 240, 360, "1", 0xffFFF981,0xffFCF9B8, true,false);
  numButtons[7] = new Button(260, 360, 300, 300, 340, 360, "2", 0xffFFF981,0xffFCF9B8, true,true);
  numButtons[8] = new Button(320, 300, 400, 300, 360, 360, "3", 0xffFFF981,0xffFCF9B8, true,false);
  numButtons[9] = new Button(200, 440, 240, 380, 280, 440, ".", 0xffFFFCBC,0xffFCFBDB, true,true);
  numButtons[10] = new Button(260, 380, 340, 380, 300, 440, "0", 0xffFFFCBC,0xffFCFBDB, true,false);
  opButtons[0] = new Button(20, 200, 60, 140, 100, 200, "C", 0xffFCF000,0xffFCF670, true,true);
  opButtons[1] = new Button(80, 140, 160, 140, 120, 200, "x^2", 0xffFCF000,0xffFCF670, true,false);
  opButtons[2] = new Button(140, 200, 180, 140, 220, 200, "+", 0xffFCF000,0xffFCF670, false,true);
  opButtons[3] = new Button(20, 220, 100, 220, 60, 280, "Log", 0xffFFF639,0xffFFFA9B, true,false);
  opButtons[4] = new Button(80, 280, 120, 220, 160, 280, "Sin", 0xffFFF639,0xffFFFA9B,true,true);
  opButtons[5] = new Button(140, 220, 220, 220, 180, 280, "-", 0xffFFF639,0xffFFFA9B,true,false);
  opButtons[6] = new Button(20, 360, 60, 300, 100, 360,"√", 0xffFFF981,0xffFCF9B8, true,true);
  opButtons[7] = new Button(80, 300, 160, 300, 120, 360, "π", 0xffFFF981,0xffFCF9B8, true,false);
  opButtons[8] = new Button(140, 360, 180, 300, 220, 360, "×", 0xffFFF981,0xffFCF9B8, true,true);
  opButtons[9] = new Button(20, 380, 100, 380, 60, 440, "=", 0xffFFFCBC,0xffFCFBDB, true,false);
  opButtons[10] = new Button(80, 440, 120, 380, 160, 440, "Cos", 0xffFFFCBC,0xffFCFBDB, true,true);
  opButtons[11] = new Button(140, 380, 220, 380, 180, 440, "÷", 0xffFFFCBC,0xffFCFBDB, true,false);  
  opButtons[12] = new Button(320, 440, 360, 380, 400, 440, "+/-", 0xffFFFCBC,0xffFCFBDB, true,true);  


}
public void draw() {
  background(230);
  for(int i = 0; i<numButtons.length; i++) {
  numButtons[i].display();
  numButtons[i].hover();
  }
  for(int i = 0; i<opButtons.length; i++) {
  opButtons[i].display();
  opButtons[i].hover();
  }
  updateDisplay();
}

public void mousePressed() { 
  println("L:" +l+"R:" +r+ "Op:" +op);
  println("Result:" +result+ "Left:" +left);
  
  //Interaction with numbers
  for (int i=0; i<numButtons.length; i++) {
    if(numButtons[i].hover && disVal.length()<20) {
      if(left) {
        if(disVal.equals("0.0")) {
          disVal = (numButtons[i].val);
          l = PApplet.parseFloat(disVal);
        } else {
          disVal += (numButtons[i].val);
          l=PApplet.parseFloat(disVal);
        }
      } else {
        if (disVal.equals("0.0")) {
          disVal = (numButtons[i].val);
          r = PApplet.parseFloat(disVal);
        } else{
          disVal+= (numButtons[i].val);
          r=PApplet.parseFloat(disVal);
        }
      }
    }
}

//Interaction with operators
 for (int i=0; i<opButtons.length; i++) {
   if(opButtons[i].hover&&opButtons[i].val.equals("C")) {
     disVal = "0.0";
     result = 0.0f;
     left = true;
     r = 0.0f;
     l = 0.0f;
     op = "";
   } else if(opButtons[i].hover&&opButtons[i].val.equals("+")) {
     if(!left) {
       performCalc();
     } else{
       op = "+";
       left = false;
       disVal = "0.0";
     }
   } else if(opButtons[i].hover&&opButtons[i].val.equals("=")) {
     performCalc();
   } else if(opButtons[i].hover&&opButtons[i].val.equals("-")) {
     if(!left) {
       performCalc();
     } else{
       op = "-";
       left = false;
       disVal = "0.0";
     }
   }else if(opButtons[i].hover&&opButtons[i].val.equals("×")) {
     if(!left) {
       performCalc();
     } else{
       op = "×";
       left = false;
       disVal = "0.0";
     }
   }else if(opButtons[i].hover&&opButtons[i].val.equals("÷")) {
     if(!left) {
       performCalc();
     } else{
       op = "÷";
       left = false;
       disVal = "0.0";
     }
   }
 }
}

public void updateDisplay() {
  fill(100);
  rect(20,20,380,100,8);
  textSize(30);
  fill(225);
  textAlign(RIGHT);
  
  //Render Scaling Text
  if(disVal.length()<18) {
    textSize(30);
  } else if (disVal.length()<25) {
    textSize(20);
  } else if (disVal.length()<30) {
    textSize(26);
  }else {
    textSize(14);
  }
    text(disVal, width-40,100);

  ////Calc Reference???
  //fill(127);
  //rectMode(CORNER);
  //rect(10,250,width-20, 52);
  
  //textSize(9);
  //textAlign(LEFT);
  //fill(255);
  //text("L:" +l+ "R:" +r+ "Op:" +op, 15,263);
  //text("Result:" + result + "Left:" + left, 15,275);
}

public void performCalc() {
  if(op.equals("+")) {
    result = l+r;
  } else if (op.equals("-")) {
    result = l-r;
  } else if (op.equals("×")) {
    result = l*r;
  }else if (op.equals("÷")) {
    result = l/r;
  }
  l = result;
  disVal = str(result);
  left = true;
}
class Button {
  //Member variables
  //mouse points
  int px, py;
  //points of triangle
  int x1, y1, x2, y2, x3, y3;
  int c1, c2;
  String val;
  boolean hover, isNumberButton, pointUp;
  //Constructor
  Button(int tempX1, int tempY1, int tempX2, int tempY2, int tempX3, int tempY3, String tempVal, int tempC1, int tempC2, boolean isNumberButton, boolean pointUp) {
    //So that I am able to choose the coordinates in Calculator.
    x1 = tempX1;
    x2 = tempX2;
    x3 = tempX3;
    y1 = tempY1;
    y2 = tempY2;
    y3 = tempY3;
    val = tempVal;
    c1 = tempC1;
    c2 = tempC2;
    val = tempVal;
    hover = false;
    this.isNumberButton = isNumberButton;
    this.pointUp = pointUp;
  }

  //Display Method
  public void display() {
    //mouse cordinates
    px = mouseX;
    py = mouseY;
    //triPoint() is defined below. 
    boolean hover = triPoint(x1, y1, x2, y2, x3, y3, px, py);
    //Determining what happens if my mouse is inside the button area
    if (isNumberButton) {

      if (hover) {
        fill(c2);
      } else {
        fill(c1);
      }
      triangle(x1, y1, x2, y2, x3, y3);
      fill(0);
      textSize(15);
      textAlign(CENTER);
      if (pointUp) {
        text(val, x1+((x3-x1)/2), y1-20);
      } else {
        text(val, x1+((x2-x1)/2), y1+30);
      }
    } else {
      if (hover) {
        fill(c2);
      } else {
        fill(c1);
      }
      triangle(x1, y1, x2, y2, x3, y3);
      fill(0);
     if (pointUp) {
        text(val, x1+((x3-x1)/2), y1-20);
      } else {
        text(val, x1+((x2-x1)/2), y1+30);
      }
    }
  }

  //Hover Method

  //TriPoint() is an area of where my mouse can be for the button to press.
  public boolean triPoint(float x1, float y1, float x2, float y2, float x3, float y3, float px, float py) {

    // this gets the area of the triangle
    float areaOrig = abs( (x2-x1)*(y3-y1) - (x3-x1)*(y2-y1) );

    // this gets the area of 3 triangles made between the point and the corners dependent on my mouse!
    float area1 =    abs( (x1-px)*(y2-py) - (x2-px)*(y1-py) );
    float area2 =    abs( (x2-px)*(y3-py) - (x3-px)*(y2-py) );
    float area3 =    abs( (x3-px)*(y1-py) - (x1-px)*(y3-py) );


    // if the sum of the three areas equals the original, we're inside the triangle!
    if (area1 + area2 + area3 == areaOrig) {
      //This is usually said hover = __ but for somereason that didn't work. So I copied the website code.
      return true;
    }
    return false;
  }

  public void hover() {
    hover = triPoint(x1, y1, x2, y2, x3, y3, px, py);
  }
}
  public void settings() {  size(420, 460); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Calculator" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
