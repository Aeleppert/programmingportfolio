import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Cars extends PApplet {

Car[] car = new Car[150];

public void setup() {
  
  for(int i=0; i<car.length;i++){
    car[i] = new Car(color(random(255), random(255), random(255)));
  }
}

public void draw() {
  background(255);
  for(int i = 0; i<car.length; i++){
  car[i].display();
  car[i].drive();
}
}
class Car {
  //member variables(inside class)
  int c;
  float xpos, ypos, xspeed;

  //constructor
  Car(int c) {
    this.c = c;
    xpos=random(width);
    ypos = random(height);
    xspeed = random(-5, 5);
  }

  public void  display() {
    rectMode(CENTER);
    fill(c);
    rect(xpos, ypos, 20, 10, 4);
    fill(0);
    rect(xpos-8, ypos-4.5f, 5, 3, 3);
    rect(xpos+8, ypos+4.5f, 5, 3, 3);
    rect(xpos-8, ypos+4.5f, 5, 3, 3);
    rect(xpos+8, ypos-4.5f, 5, 3, 3);
    if (xspeed<0) {
      fill(255);
      rect(xpos-3.5f, ypos, 5, 7, 1);
    } else {
      fill(255);
      rect(xpos+3.5f, ypos-0.4f, 5, 7, 1);
    }
  }

  public void drive() {
    xpos+= xspeed;
    if (xpos>width) {
      xpos = 0;
    } 
    if (xpos<0) {
      xpos = width;
    }
  }
}
  public void settings() {  size(800, 800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Cars" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
