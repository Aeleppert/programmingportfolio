print('Hello! Welcome to 10 Questions! We will learn more about YOU through these 10 questions')
questions = ['What is your name?','How old are you?','How are you feeling today?','Do you have any pets? If so, how many?', 'List some names of your best friends!','Why do you like your favorite food dish?','What is your favorite color?','What is your least favorite subject in school?','What is your go to joke?','If you could live anywhere else, where would you go?','What are your thoughts on pineapple on pizza?','What is the color of your kitchen cabinets?','Have you ever died your hair?','Do you like learning?','What is your go to boardgame?','Cats or Dogs?','What is your favorite season?','What are your favorite pass times?', 'Do you have any hobbies?','What do you do when you go to the beach?', 'What is your favorite clothing item you own?','What time do you get up in the morning?','What are your thoughts on the environment?','What are your thoughts on classical music?','What are your favoite songs?','What is your favorite movie?','What are your thoughts on eating snacks during a movie?']
f=open('answer.txt','a')
import random
herequestions = random.sample(questions,k=10)
i=1
x=0
while i <= 10:
  pickedquest = str(herequestions[x])
  f.write('Question:'+ pickedquest)
  print(pickedquest)
  answer = input('Answer:')
  f.write(' Answer:'+answer)
  f.write('\n')
  i=i+1
  x=x+1
f.close()
